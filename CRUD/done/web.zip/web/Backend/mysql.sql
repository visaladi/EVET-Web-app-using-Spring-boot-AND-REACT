create  database petsdetails;
use petsdetails;