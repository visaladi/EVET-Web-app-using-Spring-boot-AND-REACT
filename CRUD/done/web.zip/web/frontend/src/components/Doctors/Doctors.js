import React from "react";
import Nav from "../Nav/AfterNav";
import "./doctors.css";
import { FaUserDoctor } from "react-icons/fa6";
function Doctors() {
  return (
    <div>
      <Nav />
      {/* cover photo */}
      <div className="maincontainer">
        <div className="coverphoto"></div>
      </div>
      {/* Doc List */}
      <div className="list-container">
        <div className="list-detail">
          <tr>
            <td >
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
            </td>
            <td className="maintd"></td>
            <td>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
              <tr className="doc-tr">
                <td className="doc-td">
                  <FaUserDoctor className="doc-icon" />
                </td>
                <td className="doc-td">
                  <h1 className="doc-h1">
                    Dr.Kasun Perera<p className="doc-p">special doctor</p>
                  </h1>
                </td>
                <td className="doc-td">
                  <button className="doc-btn">Channel</button>
                </td>
              </tr>
            </td>
          </tr>
        </div>
      </div>
    </div>
  );
}

export default Doctors;
